
Three Observable Trends
-The larger the volume of rides for a city, the lower the average fare
-There is an increase in volume of rides the more dense the population (Rural - Suburban - Urban)
-There is a larger volume of rides per city with the greater number of drivers per city


```python
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import os
import seaborn as sns
```


```python
#extract file
path1 = os.path.join("Resource","ride_data.csv")
path2 = os.path.join("Resource","city_data.csv")
ride_df = pd.read_csv(path1)
city_df = pd.read_csv(path2)
city_df.head(1)
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Dataframe pyber data
pyber_df = pd.merge(city_df, ride_df, on="city")
pyber_df.head()

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-19 04:27:52</td>
      <td>5.51</td>
      <td>6246006544795</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-04-17 06:59:50</td>
      <td>5.54</td>
      <td>7466473222333</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-05-04 15:06:07</td>
      <td>30.54</td>
      <td>2140501382736</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-01-25 20:44:56</td>
      <td>12.08</td>
      <td>1896987891309</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-09 18:19:47</td>
      <td>17.91</td>
      <td>8784212854829</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Groupby 
pyber_gb = pyber_df.groupby(["type", "city"])
driver_count = pyber_gb.mean()["driver_count"]
avg_fare = pyber_gb.mean()["fare"]
ride_count = pyber_gb.count()["ride_id"]

```


```python
#Dataframe
pyberplot_df = pd.DataFrame({ "Driver Count": driver_count,
                              "Average Fare": avg_fare,
                              "Ride Count": ride_count
                                })
pyberplot_df
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Average Fare</th>
      <th>Driver Count</th>
      <th>Ride Count</th>
    </tr>
    <tr>
      <th>type</th>
      <th>city</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="18" valign="top">Rural</th>
      <th>East Leslie</th>
      <td>33.660909</td>
      <td>9.0</td>
      <td>11</td>
    </tr>
    <tr>
      <th>East Stephen</th>
      <td>39.053000</td>
      <td>6.0</td>
      <td>10</td>
    </tr>
    <tr>
      <th>East Troybury</th>
      <td>33.244286</td>
      <td>3.0</td>
      <td>7</td>
    </tr>
    <tr>
      <th>Erikport</th>
      <td>30.043750</td>
      <td>3.0</td>
      <td>8</td>
    </tr>
    <tr>
      <th>Hernandezshire</th>
      <td>32.002222</td>
      <td>10.0</td>
      <td>9</td>
    </tr>
    <tr>
      <th>Horneland</th>
      <td>21.482500</td>
      <td>8.0</td>
      <td>4</td>
    </tr>
    <tr>
      <th>Jacksonfort</th>
      <td>32.006667</td>
      <td>6.0</td>
      <td>6</td>
    </tr>
    <tr>
      <th>Kennethburgh</th>
      <td>36.928000</td>
      <td>3.0</td>
      <td>10</td>
    </tr>
    <tr>
      <th>Kinghaven</th>
      <td>34.980000</td>
      <td>3.0</td>
      <td>6</td>
    </tr>
    <tr>
      <th>Manuelchester</th>
      <td>49.620000</td>
      <td>7.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>Matthewside</th>
      <td>43.532500</td>
      <td>4.0</td>
      <td>4</td>
    </tr>
    <tr>
      <th>New Johnbury</th>
      <td>35.042500</td>
      <td>6.0</td>
      <td>4</td>
    </tr>
    <tr>
      <th>North Whitney</th>
      <td>38.146000</td>
      <td>10.0</td>
      <td>10</td>
    </tr>
    <tr>
      <th>Shelbyhaven</th>
      <td>34.828333</td>
      <td>9.0</td>
      <td>6</td>
    </tr>
    <tr>
      <th>South Elizabethmouth</th>
      <td>28.698000</td>
      <td>3.0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>South Joseph</th>
      <td>38.983333</td>
      <td>3.0</td>
      <td>12</td>
    </tr>
    <tr>
      <th>Stevensport</th>
      <td>31.948000</td>
      <td>6.0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>West Kevintown</th>
      <td>21.528571</td>
      <td>5.0</td>
      <td>7</td>
    </tr>
    <tr>
      <th rowspan="12" valign="top">Suburban</th>
      <th>Anitamouth</th>
      <td>37.315556</td>
      <td>16.0</td>
      <td>9</td>
    </tr>
    <tr>
      <th>Campbellport</th>
      <td>33.711333</td>
      <td>26.0</td>
      <td>15</td>
    </tr>
    <tr>
      <th>Carrollbury</th>
      <td>36.606000</td>
      <td>4.0</td>
      <td>10</td>
    </tr>
    <tr>
      <th>Clarkstad</th>
      <td>31.051667</td>
      <td>21.0</td>
      <td>12</td>
    </tr>
    <tr>
      <th>Conwaymouth</th>
      <td>34.591818</td>
      <td>18.0</td>
      <td>11</td>
    </tr>
    <tr>
      <th>East Cherylfurt</th>
      <td>31.416154</td>
      <td>9.0</td>
      <td>13</td>
    </tr>
    <tr>
      <th>East Jenniferchester</th>
      <td>32.599474</td>
      <td>22.0</td>
      <td>19</td>
    </tr>
    <tr>
      <th>Floresberg</th>
      <td>32.310000</td>
      <td>7.0</td>
      <td>10</td>
    </tr>
    <tr>
      <th>Jasonfort</th>
      <td>27.831667</td>
      <td>25.0</td>
      <td>12</td>
    </tr>
    <tr>
      <th>Jeffreyton</th>
      <td>33.165556</td>
      <td>8.0</td>
      <td>18</td>
    </tr>
    <tr>
      <th>Johnland</th>
      <td>28.752778</td>
      <td>13.0</td>
      <td>18</td>
    </tr>
    <tr>
      <th>Kyleton</th>
      <td>31.167500</td>
      <td>12.0</td>
      <td>16</td>
    </tr>
    <tr>
      <th>...</th>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th rowspan="30" valign="top">Urban</th>
      <th>Port Martinberg</th>
      <td>22.329524</td>
      <td>44.0</td>
      <td>21</td>
    </tr>
    <tr>
      <th>Port Samantha</th>
      <td>27.047407</td>
      <td>55.0</td>
      <td>27</td>
    </tr>
    <tr>
      <th>Prattfurt</th>
      <td>23.346667</td>
      <td>43.0</td>
      <td>24</td>
    </tr>
    <tr>
      <th>Rodriguezburgh</th>
      <td>21.332609</td>
      <td>52.0</td>
      <td>23</td>
    </tr>
    <tr>
      <th>Russellport</th>
      <td>22.486087</td>
      <td>9.0</td>
      <td>23</td>
    </tr>
    <tr>
      <th>Sandymouth</th>
      <td>23.105926</td>
      <td>11.0</td>
      <td>27</td>
    </tr>
    <tr>
      <th>Sarabury</th>
      <td>23.490000</td>
      <td>46.0</td>
      <td>27</td>
    </tr>
    <tr>
      <th>Smithhaven</th>
      <td>22.788889</td>
      <td>67.0</td>
      <td>27</td>
    </tr>
    <tr>
      <th>South Bryanstad</th>
      <td>24.598571</td>
      <td>73.0</td>
      <td>21</td>
    </tr>
    <tr>
      <th>South Josephville</th>
      <td>26.823750</td>
      <td>4.0</td>
      <td>24</td>
    </tr>
    <tr>
      <th>South Louis</th>
      <td>27.087500</td>
      <td>12.0</td>
      <td>32</td>
    </tr>
    <tr>
      <th>South Roy</th>
      <td>26.031364</td>
      <td>35.0</td>
      <td>22</td>
    </tr>
    <tr>
      <th>Spencertown</th>
      <td>23.681154</td>
      <td>68.0</td>
      <td>26</td>
    </tr>
    <tr>
      <th>Stewartview</th>
      <td>21.614000</td>
      <td>49.0</td>
      <td>30</td>
    </tr>
    <tr>
      <th>Swansonbury</th>
      <td>27.464706</td>
      <td>64.0</td>
      <td>34</td>
    </tr>
    <tr>
      <th>Torresshire</th>
      <td>24.207308</td>
      <td>70.0</td>
      <td>26</td>
    </tr>
    <tr>
      <th>Travisville</th>
      <td>27.220870</td>
      <td>37.0</td>
      <td>23</td>
    </tr>
    <tr>
      <th>Vickimouth</th>
      <td>21.474667</td>
      <td>13.0</td>
      <td>15</td>
    </tr>
    <tr>
      <th>West Alexis</th>
      <td>19.523000</td>
      <td>47.0</td>
      <td>20</td>
    </tr>
    <tr>
      <th>West Brandy</th>
      <td>24.157667</td>
      <td>12.0</td>
      <td>30</td>
    </tr>
    <tr>
      <th>West Brittanyton</th>
      <td>25.436250</td>
      <td>9.0</td>
      <td>24</td>
    </tr>
    <tr>
      <th>West Dawnfurt</th>
      <td>22.330345</td>
      <td>34.0</td>
      <td>29</td>
    </tr>
    <tr>
      <th>West Jefferyfurt</th>
      <td>21.072857</td>
      <td>65.0</td>
      <td>21</td>
    </tr>
    <tr>
      <th>West Oscar</th>
      <td>24.280000</td>
      <td>11.0</td>
      <td>29</td>
    </tr>
    <tr>
      <th>West Peter</th>
      <td>24.875484</td>
      <td>61.0</td>
      <td>31</td>
    </tr>
    <tr>
      <th>West Sydneyhaven</th>
      <td>22.368333</td>
      <td>70.0</td>
      <td>18</td>
    </tr>
    <tr>
      <th>Williamshire</th>
      <td>26.990323</td>
      <td>70.0</td>
      <td>31</td>
    </tr>
    <tr>
      <th>Wiseborough</th>
      <td>22.676842</td>
      <td>55.0</td>
      <td>19</td>
    </tr>
    <tr>
      <th>Yolandafurt</th>
      <td>27.205500</td>
      <td>7.0</td>
      <td>20</td>
    </tr>
    <tr>
      <th>Zimmermanmouth</th>
      <td>28.301667</td>
      <td>45.0</td>
      <td>24</td>
    </tr>
  </tbody>
</table>
<p>125 rows × 3 columns</p>
</div>




```python
# Create data series by type
pyber_df_rural = pyber_df[(pyber_df["type"] == "Rural")]
pyber_df_urban = pyber_df[(pyber_df["type"] == "Urban")]
pyber_df_suburban = pyber_df[(pyber_df["type"] == "Suburban")]

#for rural
driver_count_rural = pyber_df_rural.groupby(["city"]).mean()["driver_count"]
avg_fare_rural = pyber_df_rural.groupby(["city"]).mean()["fare"]
ride_count_rural = pyber_df_rural.groupby(["city"]).count()["ride_id"]

#for urban
driver_count_urban = pyber_df_urban.groupby(["city"]).mean()["driver_count"]
avg_fare_urban = pyber_df_urban.groupby(["city"]).mean()["fare"]
ride_count_urban = pyber_df_urban.groupby(["city"]).count()["ride_id"]

#for suburban
driver_count_suburban = pyber_df_suburban.groupby(["city"]).mean()["driver_count"]
avg_fare_suburban = pyber_df_suburban.groupby(["city"]).mean()["fare"]
ride_count_suburban = pyber_df_suburban.groupby(["city"]).count()["ride_id"]

```


```python
fig, ax = plt.subplots()

fig.suptitle("Pyber Ride Sharing Data (2016)", fontsize=16, fontweight="bold")

ax.set_xlim(0, 40)
ax.set_ylim(15, 45)

ax.set_xlabel("Total Number of Rides (per City)")
ax.set_ylabel("Average Fare ($)")

#Plot urban
plt.scatter(ride_count_urban, avg_fare_urban, marker="o", facecolors="coral", edgecolors="black",
            s=driver_count_urban*5, alpha=0.75, label="Urban")

#Plot rural
plt.scatter(ride_count_rural, avg_fare_rural, marker="o", facecolors="gold", edgecolors="black",
            s=driver_count_rural*5, alpha=0.75, label="Rural")

#Plot suburban
plt.scatter(ride_count_suburban, avg_fare_suburban, marker="o", facecolors="lightblue", edgecolors="black",
            s=driver_count_suburban*5, alpha=0.75, label="Suburban")

ax.legend(loc='upper right', fontsize='medium')

plt.show()
```


![png](output_7_0.png)



```python
#City type sum fare
pyber_type = pyber_df.groupby(["type"])

# Collect the trips of the 'bikeid' above
sumby_fare = pyber_type.sum()["fare"]

# Create a pie chart based upon the trip duration of that
# single bike
fare_pie = sumby_fare.plot(kind="pie")
plt.title("% of Total Fares by City Type")

plt.show()
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-14-40eb746e3572> in <module>()
          7 # Create a pie chart based upon the trip duration of that
          8 # single bike
    ----> 9 fare_pie = sumby_fare.plot(kind="pie", explode=explode)
         10 plt.title("% of Total Fares by City Type")
         11 


    NameError: name 'explode' is not defined



```python
#City type sum rides
pyber_type = pyber_df.groupby(["type"])

# Collect the trips of the 'bikeid' above
sumby_ride = pyber_type.count()["ride_id"]

# Create a pie chart based upon the trip duration of that
# single bike
fare_pie = sumby_ride.plot(kind="pie")
plt.title("% of Total Rides by City Type")

plt.show()
```


![png](output_9_0.png)



```python
#City type sum drivers
pyber_type = pyber_df.groupby(["type"])

# Collect the trips of the 'bikeid' above
sumby_driver = pyber_type.sum()["driver_count"]

# Create a pie chart based upon the trip duration of that
# single bike
fare_pie = sumby_driver.plot(kind="pie")
plt.title("% of Total Drivers by City Type")

plt.show()
```


![png](output_10_0.png)

